export const metadata = {
  title: "Yui AI",
  description: "Visual Effect AI Artist for sensual anime characters.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-black text-white">{children}</body>
    </html>
  );
}
