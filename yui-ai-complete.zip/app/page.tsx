"use client";

import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-black to-zinc-900 text-white px-4 py-10">
      <section className="text-center max-w-2xl mx-auto">
        <h1 className="text-5xl font-bold mb-4">Yui AI</h1>
        <p className="text-lg text-zinc-300 mb-6">
          Visual Effect AI Artist khusus karakter anime sensual. Hadir dengan teknologi generatif untuk menciptakan karakter anime yang menggoda dan menggugah imajinasi.
        </p>
        <Link href="https://x.com/YuiAiart" target="_blank">
          <button className="bg-pink-600 hover:bg-pink-700 text-white font-semibold px-6 py-2 rounded-full">
            Lihat di Twitter
          </button>
        </Link>
      </section>
    </main>
  );
}
